// Shared base-map helper.
//  - OpenStreetMap tiles, auto-fallback to CARTO if OSM refuses
//  - Shows a visible message inside the map box if something is wrong

function mapProblem(el, msg) {
  if (!el || el.querySelector('.map-problem')) return;
  const inApp = /Electron|Code\//i.test(navigator.userAgent);
  const box = document.createElement('div');
  box.className = 'map-problem';
  box.style.cssText = 'position:absolute;left:10px;right:10px;top:10px;z-index:1000;background:#fff3cd;' +
    'border:2px solid #ffc107;border-radius:8px;padding:10px 14px;font:14px/1.4 system-ui,sans-serif;color:#533f03;';
  box.innerHTML = '<b>⚠️ Map problem:</b> ' + msg +
    '<br><small>Page: ' + location.href + '</small>' +
    (inApp ? '<br><small><b>You are viewing this inside VS Code.</b> Open <b>http://localhost:3000</b> in Chrome or Edge instead.</small>' : '') +
    (location.protocol === 'file:' ? '<br><small><b>Opened as a file.</b> Start the server (npm start) and use http://localhost:3000</small>' : '');
  if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
  el.appendChild(box);
}

// Leaflet library itself failed to load (blocked / offline)
if (typeof L === 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    ['map', 'route-map', 'waiting-map', 'result-map', 'modal-map'].forEach(id => {
      const el = document.getElementById(id);
      if (el) mapProblem(el, 'The Leaflet map library could not load (no internet, or the network/VS Code blocks it).');
    });
  });
}

function addBaseTiles(map) {
  if (typeof L === 'undefined') return;
  const el = map.getContainer();
  let provider = 'osm', errors = 0, loaded = 0;

  function make(url, opts) {
    const layer = L.tileLayer(url, opts).addTo(map);
    layer.on('tileload', () => { loaded++; const b = el.querySelector('.map-problem'); if (b) b.remove(); });
    layer.on('tileerror', () => {
      errors++;
      if (errors < 3 || loaded > 0) return;
      if (provider === 'osm') {
        provider = 'carto'; errors = 0;
        map.removeLayer(layer);
        make('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
          { attribution: '© OpenStreetMap contributors © CARTO', subdomains: 'abcd', maxZoom: 19 });
      } else {
        mapProblem(el, 'Map tiles could not be downloaded. Check your internet connection, firewall/VPN or ad-blocker.');
      }
    });
    return layer;
  }

  make('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    maxZoom: 19
  });

  // Fix grey/partial maps created while layout is still settling
  [100, 400, 1000].forEach(ms => setTimeout(() => map.invalidateSize(), ms));
  window.addEventListener('resize', () => map.invalidateSize());

  // If nothing at all loaded after a few seconds, say so
  setTimeout(() => {
    if (loaded === 0 && !el.querySelector('.map-problem')) {
      mapProblem(el, 'No map tiles loaded yet. This usually means no internet access, or the page was opened the wrong way.');
    }
  }, 6000);
}
