# Ambulance Signal System

    npm install
    npm start

Open http://localhost:3000
- /register   register an ambulance (get AMB-XXXXXXXX id)
- /emergency  verify id, search places, request green corridor (admin approves)
- /driver     pick on map, auto-activates corridor, optional drive simulation
- /admin      dashboard (default login: admin / admin123)

Requires internet for map tiles, OSRM routing, Nominatim and Overpass.

## Running in VS Code
1. Open the project folder in VS Code, then Terminal > New Terminal.
2. `npm install` then `npm start` (keep it running).
3. Open http://localhost:3000 in Chrome/Edge/Firefox (not VS Code's built-in preview).
Live Server (port 5500) also works for the pages as long as `npm start` is running.

## Easiest ways to start
- VS Code: press Ctrl+Shift+B (installs + starts the server), then open http://localhost:3000
- VS Code: press F5 (starts server and opens the browser)
- Windows: double-click start.bat
- Live Server (right-click public/index.html > Open with Live Server) also works,
  but the Node server (above) must be running at the same time.
